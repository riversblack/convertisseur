/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.net.URL;
import java.util.ResourceBundle;
import static javafx.application.ConditionalFeature.FXML;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author RIVERSBLACK Bmbyor
 */
public class ConvertisseurController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    Button btnConvertir = new Button();
    @FXML
    Button btnAnnuler = new Button();
    @FXML
    TextField textMontant = new TextField();
    @FXML
    TextField textResultat = new TextField();
    @FXML
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    } 
    @FXML
    private void convertir(ActionEvent evt){
        Double montant;
        montant = Double.parseDouble(textMontant.getText());
        textResultat.setText(""+(montant/2000));
    }
    @FXML
    private void annuler(ActionEvent evt){
        textMontant.setText("0.0");
        textResultat.setText("0.0");
    }
    
}
